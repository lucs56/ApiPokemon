import { useEffect, useState } from 'react';
import PokemonCard from './components/PokemonCard';
import PokemonDetail from './components/PokemonDetail';
import TypeFilter from './components/TypeFilter';

function App() {
  const [pokemonList, setPokemonList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [offset, setOffset] = useState(0);
  const [totalPokemons, setTotalPokemons] = useState(0);
  const [favorites, setFavorites] = useState(() => {
    const saved = localStorage.getItem('favorites');
    return saved ? JSON.parse(saved) : [];
  });
  const [selectedPokemon, setSelectedPokemon] = useState(null);
  const [selectedType, setSelectedType] = useState('all');

  const limit = 20;
  const pageNumber = Math.floor(offset / limit) + 1;

  const fetchPokemons = async () => {
    setLoading(true);
    try {
      const res = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=${limit}&offset=${offset}`);
      const data = await res.json();

      setTotalPokemons(data.count);

      const detailed = await Promise.all(
        data.results.map(async (pokemon) => {
          const res = await fetch(pokemon.url);
          return await res.json();
        })
      );

      setPokemonList(detailed);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPokemons();
  }, [offset]);

  const handleSearch = async () => {
    if (search.trim() === '') {
      fetchPokemons();
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`https://pokeapi.co/api/v2/pokemon/${search.toLowerCase()}`);
      if (!res.ok) {
        setPokemonList([]);
      } else {
        const data = await res.json();
        setPokemonList([data]);
      }
    } catch {
      setPokemonList([]);
    } finally {
      setLoading(false);
    }
  };

  const toggleFavorite = (pokemon) => {
    const updatedFavorites = favorites.some(p => p.id === pokemon.id)
      ? favorites.filter(p => p.id !== pokemon.id)
      : [...favorites, pokemon];

    setFavorites(updatedFavorites);
    localStorage.setItem('favorites', JSON.stringify(updatedFavorites));
  };

  const filteredList =
    selectedType === 'all'
      ? pokemonList
      : pokemonList.filter(p =>
          p.types.some(t => t.type.name === selectedType)
        );

  return (
    <div style={{ backgroundColor: '#121212', color: '#fff', minHeight: '100vh', padding: '20px' }}>
      <h1 style={{ textAlign: 'center', fontSize: '2.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px' }}>
        <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="pokeball" width="40" height="40" />
        <span style={{ color: '#FFCB05' }}>Pokémon</span>
        <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png" alt="pokeball" width="40" height="40" />
      </h1>

      {/* Búsqueda */}
      <div style={{ marginBottom: '20px', textAlign: 'center' }}>
        <input
          type="text"
          placeholder="Buscar Pokémon"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ padding: '8px', width: '200px' }}
        />
        <button onClick={handleSearch} style={{ marginLeft: '10px', padding: '8px' }}>
          Buscar
        </button>
      </div>

      {/* Filtro por tipo */}
      <div style={{ textAlign: 'center' }}>
        <TypeFilter selectedType={selectedType} setSelectedType={setSelectedType} />
      </div>

      {/* Paginación */}
      <div style={{ marginBottom: '10px', textAlign: 'center' }}>
        <button
          onClick={() => setOffset(Math.max(0, offset - limit))}
          disabled={offset === 0}
        >
          ← Anterior
        </button>
        <span style={{ margin: '0 10px' }}>Página: {pageNumber}</span>
        <button
          onClick={() => setOffset(offset + limit)}
          disabled={offset + limit >= totalPokemons}
        >
          Siguiente →
        </button>
      </div>

      {/* Lista de Pokémon */}
      {loading ? (
        <h2 style={{ textAlign: 'center' }}>Cargando...</h2>
      ) : filteredList.length > 0 ? (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', justifyContent: 'center' }}>
          {filteredList.map((poke) => (
            <PokemonCard
              key={poke.id}
              pokemon={poke}
              onClick={setSelectedPokemon}
              isFavorite={favorites.some(f => f.id === poke.id)}
              onToggleFavorite={toggleFavorite}
            />
          ))}
        </div>
      ) : (
        <h3 style={{ textAlign: 'center' }}>No se encontraron resultados</h3>
      )}

      {/* Detalle en modal */}
      <PokemonDetail pokemon={selectedPokemon} onClose={() => setSelectedPokemon(null)} />

      {/* Favoritos */}
      <div style={{ marginTop: '40px' }}>
        <h2>❤️ Tus Favoritos</h2>
        {favorites.length === 0 ? (
          <p>No tenés favoritos aún.</p>
        ) : (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
            {favorites.map((poke) => (
              <PokemonCard
                key={poke.id}
                pokemon={poke}
                onClick={setSelectedPokemon}
                isFavorite={true}
                onToggleFavorite={toggleFavorite}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
